﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp10
{
    public partial class Form1 : Form
    {
       
        public Form1()
        {
            InitializeComponent();
        }

        private void BtCalcular_Click(object sender, EventArgs e)
        {
            if ((text_VA.Text != "") && (text_VB.Text != ""))
            {

                float resultado = (float.Parse(text_VA.Text) * float.Parse(text_VA.Text)) / float.Parse(text_VB.Text);

                if (resultado < 20)
                {
                    text_Resultado.Text = "Abaixo do peso";
                }
                if (resultado > 25)
                {
                    text_Resultado.Text = "Acima do peso";
                }
                else
                if (resultado >= 20 && resultado <= 25)
                {
                    text_Resultado.Text = "Peso ideal";
                }
                LbMensagem.Text = "Comparação efetuado!!";
            }
            else
            {
                LbMensagem.Text = "Digite os respectivos valores para efetuar a comparação...";
            }

        }

        private void BtLimpar_Click(object sender, EventArgs e)
        {
            text_Resultado.Text = null;
            text_VA.Text = null;
            text_VB.Text = null;
            LbMensagem.Text = null;;
        }
    }
}
