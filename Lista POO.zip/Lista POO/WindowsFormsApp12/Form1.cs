﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp11
{
    public partial class Form1 : Form
    {
        decimal va, vb, vc;

        private void BtLimpar_Click(object sender, EventArgs e)
        {
            a1.Text = null;
            b1.Text = null;
            c1.Text = null;
            TbResultado.Text = null;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void BtCalcular_Click(object sender, EventArgs e)
        {
            if (((a1.Text != "") && (b1.Text != "")) && (c1.Text != ""))
            {
                va = Convert.ToDecimal(a1.Text);
                vb = Convert.ToDecimal(b1.Text);
                vc = Convert.ToDecimal(c1.Text);

                if (va + vb > vc && va + vc > vb && vb + vc > va)
                
                    if (va == vb && va == vc)
                    {
                        TbResultado.Text = "Triangulo equilatero";
                    }
                    else
                    if (va == vb || va == vc || vb == vc)
                    {
                        TbResultado.Text = "Triangulo isosceles";
                    }
                    else
                        TbResultado.Text = "Triangulo escaleno";
                    else
                        TbResultado.Text = "Não formam um triangulo";
            }

        }
    }
}
