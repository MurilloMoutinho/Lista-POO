﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp7
{
    public partial class Form1 : Form
    {
        decimal va, vb;

        public Form1()
        {
            InitializeComponent();
        }

        private void BtLimpar_Click(object sender, EventArgs e)
        {
            text_VA.Text = null;
            text_VB.Text = null;
            TbResultado.Text = null;
            LbMensagem.Text = null; 
        }

        private void BtCalcular_Click(object sender, EventArgs e)
        {
     

            if ((text_VA.Text != "") && (text_VB.Text != ""))
            {
                va = Convert.ToDecimal(text_VA.Text);
                vb = Convert.ToDecimal(text_VB.Text);
                if (va > vb)
                {
                    TbResultado.Text = $"O maior valor digitado foi o {va} ";
                }
                else
                {
                    TbResultado.Text = $"O maior valor digitado foi o {vb}";
                }
                LbMensagem.Text = "Comparação efetuado!!";
            }
            else
            {
                LbMensagem.Text = "Digite os respectivos valores para efetuar a comparação...";
            }

        }
    }
}
